What is this software:
This is Coinbend. It's the first p2p exchange for cryptocurrencies that works without a third-party. You can currently use the software to trade cryptocurrencies with strangers without the risk of scamming or theft. Note that this software is only a pre-alpha release. Not to be used with real money for now.

How to use the software for the first time:
1. Download and install any cryptocurrencies you want to use. They must be forks of the Bitcoin code that haven't fundamentally changed the transaction format or RPC interface. Examples include Litecoin, Namecoin, Dogecoin, Peercoin, etc.
2. Run any cryptocurrency clients you want to use. When you see the UI, close and exit the program. This will make sure that their data directory has been created.
3. Windows: Now run windows_install.bat. Linux: Or run linux_install.sh from the terminal.
4. Windows: Start coinbend.exe. Linux: Run ./coinbend from the terminal. The software will need to make a few changes to your cryptocurrencies' config files so it can interact with the clients. Press enter to exit.
5. Restart all your cryptocurrencies. You should see that they are now running on the the testnet - this is good. If they are not - close the client because something has gone wrong and you don't want to use this software with real money just yet.
6. Restart coinbend. The software will print a lot of debug statements and appear to freeze at certain points. Simply wait until you see a URL printed like: http://127.0.0.1:7777/.
7. Alright, now visit http://127.0.0.1:7777/ in your web browser.
8. ?????????????
9. Disclaimer: This is a buggy pre-alpha release that works for trading cryptocurrencies without a third-party. It's currently missing a lot of important features that will be needed for a commercial release: i.e. at the moment p2p matching only works if two trades match exactly (so p2p trades won't work very well.) There is also no way to close a trade or even load old trades / contracts when you restart the program, plus we're still working on our design for timechains so I suggest you only use this software with testcoins.

One good way to test trading is with the direct trading feature: When you open a new trade: click generate node ID. You can give your node ID to a friend so they can trade directly with you which helps with testing. To use this feature both sides need to enter each other's node IDs so make sure you grab their ID too before you press accept.

Anyway, that's it for now. I hope you find this interesting.

Source code:
www.github.com/robertsdotpm/coinbend
matthew@roberts.pm
