mkdir ~/.Coinbend
mv install/* ~/.Coinbend
